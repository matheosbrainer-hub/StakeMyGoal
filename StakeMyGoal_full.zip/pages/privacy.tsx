import Navbar from '@/components/Navbar';
export default function Privacy(){ return (
  <div><Navbar /><div className="max-w-4xl mx-auto p-6 text-gray-200">
    <h1 className="text-3xl font-bold mb-4">Privacy Policy</h1>
    <p>Placeholder privacy policy. Replace with legal text.</p>
  </div></div>
)}